﻿Przekształcenie normalnych.

Demonstruje:
1. jak utworzyć macierz przekształcenia normalnych
2. jak ją przekazać do vertex shadera

Zadanie:
1. zmodyfikować klasę Model, aby tworzyła ona automatycznie bufor EBO dla wczytanego modelu
