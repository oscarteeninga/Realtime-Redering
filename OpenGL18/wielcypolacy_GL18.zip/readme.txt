﻿Zastosowanie tekstury jako koloru ambient i diffuse.

Demonstruje:
1. jak wczytać teksturę
2. jak załadować teksturę do karty graficznej
3. jak korzystać z tekstury w shaderze

Zadanie:
1. Przygotować (np. paintem) inną ciekawą teksturę dla kostki (kostkę do gry, Rubika, itp.). Należy zwrócić uwagę na współrzędne tekstury w modelu.
